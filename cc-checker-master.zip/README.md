# CC Checker

u need to edit the check.php file
